package com.greenpineyu.fel.common;

/**
 * 用于表示Null值
 * @author yuqingsong
 *
 */
public class Null {

}
